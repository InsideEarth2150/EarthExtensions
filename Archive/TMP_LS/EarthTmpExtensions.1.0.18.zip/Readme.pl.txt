==================================
 Inside Earth Operations presents
*** Earth 2150: TMP Extensions ***
        by GvardianDLVII
==================================
Wersja 1.0.18

InsideEarth - Community Discord Server: https://discord.gg/yxtzdUZ

1. Instalacja (TMP i LS)
   - upewnić się żę gra jest w wersji min 2.1.1, lub 2.2.1
   - podminić plik EarthTmpExtensions.ieo w folderze "Modules" w katalogu z grą

2. Funkcjonalności i konfiguracja
Dostępne na https://wiki.insideearth.info/wiki/EarthTmpExtensions

3. Podziękowania dla:
- Animal, za testowanie i zgłaszanie błędów
- InsideEARTH community

Changelog:
1.0.18:
   - automatyczne dodawanie prefiksu kanału wiadomości na czacie (All/Team/Neutral/Direct)
1.0.17:
   - zmniejszenie opóźnienia GUI przy wydawaniu rozkazów (funkcjonalność eksperymentalna, tymczasowo wymaga ręcznego włączenia w pliku ini)
   - nowe polecenia w konsoli: "IEO.Ping" i "IEO.LoadObjects"
1.0.15:
   - poprawka przybliżania kamery w kampanii (thx to Hunter3k0)
   - poprawka w wyswietlaniu tekstur w konstruktorze
1.0.14:
   - dodanie konfiguracji skalowania efektu wstrząsu kamery przy eksplozjach (domyślnie zmniejszono z 1.0 na 0.5)
1.0.13:
   - zmiana typu pliku z .mdl na .ieo
   - dodanie wsparcia dla Lost Souls
1.0.12:
   - usunięto parę poprawke które stały się częścią poprawionego w 2.2.1 exe
   - zmiany w oknie opcji
   - kompatybilność ze świeżo zainstalowanym Windowsem (thx to jmp32)
1.0.9:
   - poprawka "skaczącego kursora"
   - możliwość ustawienia FPS
   - wyłączenie optymalizacji renderingu dla innych rendererów niż Direct3D bo crashowały (nGlide, OpenGL etc)
1.0.8:
   - poprawka w przybliżaniu na wielu widokach
1.0.7:
   - dodano płynne przybliżanie/oddalanie widoku
1.0.6:
   - poprawiono wyświetlanie efektów na jednostkach i budynkach, które czasami wyświetlały się "za obiektem"
